package com.wipro.springboot.rest.app;

import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
public class ProductService{
	
	@Autowired
	ProductRepository productRepository;

	public List<ProductCatalogue> find()
	{
		return  productRepository.findAll();
		
	}
	
	public void save(ProductCatalogue arg)
	{
		productRepository.save(arg);
	}
	
	public void deleteById(int id)
	{
		productRepository.deleteById(id);
	}

	public ProductCatalogue getById(int id) {
		
			return productRepository.getOne(id);
		
	}
	
}
