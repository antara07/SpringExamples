package com.wipro.SpringBootRestApp;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wipro.springboot.rest.app.ProductCatalogue;
import com.wipro.springboot.rest.app.ProductRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@DataJpaTest
public class ApplicationDemoTests {

	@Autowired
	private TestEntityManager testEntityManager;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Test
	public void deleteById() {
		testEntityManager.persist(new ProductCatalogue(222,"test",300.50));
		productRepository.deleteById(222);
		assertThat(productRepository.findById(222)).isNull();
	}

}
