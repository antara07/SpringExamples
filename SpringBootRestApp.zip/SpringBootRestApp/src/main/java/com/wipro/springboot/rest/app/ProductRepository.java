package com.wipro.springboot.rest.app;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<ProductCatalogue,Integer> {

}
