package com.wipro.springboot.rest.app;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController

public class ProductController {
	
	@Autowired
	ProductService service;
	
	@GetMapping("/get")
	public List<ProductCatalogue> get()
	{
		return service.find();
	}
	
	@GetMapping("/get/{id}")
	public ProductCatalogue getById(@PathVariable int id)
	{
		return service.getById(id);
	}
	
	
	@PostMapping("/add")
	public void saveProduct(@RequestBody ProductCatalogue arg)
	{
		service.save(arg);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteProduct(@PathVariable int id)
	{
		service.deleteById(id);
	}
}
